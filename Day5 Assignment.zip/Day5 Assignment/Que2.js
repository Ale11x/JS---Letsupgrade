<script language='javascript' type='text/javascript'>
    var userid = "<?php echo $username; ?>";//username is the session variable
 if (userid==(""))//indicaates that no one is logged in
 $('#det_login').toggleClass('hide');
 else
 $('#det_logout').toggleClass('hide');
</script>


    <li id="det_login"><a href="javascript:login('show');" class="nav2"> login</a><li>

        <li id="det_logout" class="hide"  ><a href="javascript:login2('show');" class="nav2"><?</a><li></li>