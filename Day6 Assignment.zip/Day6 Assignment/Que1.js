let colors = ['red', 'green', 'blue'];
for (const color of colors) {
    console.log(color);
}