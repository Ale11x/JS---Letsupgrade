alert("Hey!! What is your goal today? Just click on 'OK'and GET YOUR QUOTE");
document.write(Date());

let btn = document.getElementById('btn');
let output = document.getElementById('output');
let quotes = [
    'The greatest glory in living lies not in never falling, but in rising every time we fall -Nelson Mandela',
    'Your time is limited, so don\'t waste it living someone else\'s life. Don\'t be trapped by dogma – which is living with the results of other people\'s thinking -Steve Jobs',
    'If you look at what you have in life, you\'ll always have more. If you look at what you don\'t have in life, you\'ll never have enough -Oprah Winfrey',
    'The real test is not whether you avoid this failure, because you won\'t. It\'s whether you let it harden or shame you into inaction, or whether you learn from it whether you choose to persevere -Barack Obama',
    'Successful people do what unsuccessful people are not willing to do. Don\'t wish it were easier wish you were better -Jim Rohn',
    'People who succeed have momentum. The more they succeed, the more they want to succeed and the more they find a way to succeed. Similarly, when someone is failing, the tendency is to get on a downward spiral that can even become a self-fulfilling prophecy -Tony Robbins',
    'I have learned that people will forget what you said, people will forget what you did, but people will never forget how you made them feel -Maya Angelou',
    'When everything seems to be going against you, remember that the airplane takes off against the wind, not with it -Henry Ford',
    'First, have a definite, clear practical ideal a goal, an objective. Second, have the necessary means to achieve your ends wisdom, money, materials, and methods. Third, adjust all your means to that end -Aristotle',
    'Twenty years from now you will be more disappointed by the things that you didn\'t do than by the ones you did do. So, throw off the bowlines, sail away from safe harbor, catch the trade winds in your sails. Explore, Dream, Discover -Mark Twain',
    'First, have a definite, clear practical ideal a goal, an objective. Second, have the necessary means to achieve your ends wisdom, money, materials, and methods. Third, adjust all your means to that end -Aristotle'
];

btn.addEventListener('click', function () {
    var randomQuote = quotes[Math.floor(Math.random() * quotes.length)]
    output.innerHTML = randomQuote;
})

function myFunction() {
    var person = prompt("Please enter your MailID", "@gmail.com");
    if (person != null) {
        document.getElementById("demo").innerHTML =
            "Thankyou! " + person + " You will get daily new quotes from now";
    }
}